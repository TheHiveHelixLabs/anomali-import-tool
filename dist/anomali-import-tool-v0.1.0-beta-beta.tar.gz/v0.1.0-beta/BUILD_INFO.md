# Build Information

**Build Date**: Thu Jun 26 01:11:10 PM CDT 2025  
**Build Environment**: Linux 6.11.0-26-generic  
**.NET Version**: 8.0.407  
**Build Configuration**: Release  

## Build Results

✅ Package: ..
✅ Package: core-library
✅ Package: developer-package
✅ Package: documentation

## Build Warnings

- Infrastructure project has compilation errors
- Windows-specific components cannot be built on Linux
- Some advanced features are not yet implemented

## Package Sizes

- 0	dist/v0.1.0-beta/BUILD_INFO.md
- 260K	dist/v0.1.0-beta/core-library
- 3.1M	dist/v0.1.0-beta/developer-package
- 452K	dist/v0.1.0-beta/documentation
- 4.0K	dist/v0.1.0-beta/README.md


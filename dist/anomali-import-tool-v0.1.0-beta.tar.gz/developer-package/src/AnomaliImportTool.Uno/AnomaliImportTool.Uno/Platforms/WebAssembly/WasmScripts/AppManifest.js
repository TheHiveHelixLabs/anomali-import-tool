var UnoAppManifest = {
    displayName: "AnomaliImportTool.Uno"
}

# About the `.run` folder

This folder is present to add support for the [Rider IDE](https://aka.platform.uno/rider-getstarted). You can remove this folder safely if you're not using Rider.

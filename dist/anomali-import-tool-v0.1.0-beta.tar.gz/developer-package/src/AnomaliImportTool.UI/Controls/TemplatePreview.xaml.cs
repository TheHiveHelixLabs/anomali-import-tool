using System.Windows.Controls;

namespace AnomaliImportTool.WPF.Controls
{
    public partial class TemplatePreview : UserControl
    {
        public TemplatePreview()
        {
            InitializeComponent();
        }
    }
} 
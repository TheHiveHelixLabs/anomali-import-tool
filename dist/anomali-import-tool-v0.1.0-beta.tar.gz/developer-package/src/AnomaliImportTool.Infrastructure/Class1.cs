﻿namespace AnomaliImportTool.Infrastructure;

public class Class1
{

}

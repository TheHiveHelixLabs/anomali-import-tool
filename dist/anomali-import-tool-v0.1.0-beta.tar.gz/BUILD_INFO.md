# Build Information

**Build Date**: Thu Jun 26 01:26:15 PM CDT 2025  
**Build Environment**: Linux 6.11.0-26-generic  
**.NET Version**: 8.0.407  
**Build Configuration**: Release  

## Build Results

✅ Package: core-library-v0.1.0-beta
✅ Package: developer-package-v0.1.0-beta
✅ Package: documentation-v0.1.0-beta

## Build Warnings

- Infrastructure project has compilation errors
- Windows-specific components cannot be built on Linux
- Some advanced features are not yet implemented

## Package Sizes

0	BUILD_INFO.md
260K	core-library
96K	core-library-v0.1.0-beta.tar.gz
16K	developer-package/src/AnomaliImportTool.Infrastructure/ApiClient
48K	developer-package/src/AnomaliImportTool.Infrastructure/Database
20K	developer-package/src/AnomaliImportTool.Infrastructure/Security
12K	developer-package/src/AnomaliImportTool.Infrastructure/DependencyInjection
4.0K	developer-package/src/AnomaliImportTool.Infrastructure/DocumentProcessing/Strategies
112K	developer-package/src/AnomaliImportTool.Infrastructure/DocumentProcessing
292K	developer-package/src/AnomaliImportTool.Infrastructure/Services
16K	developer-package/src/AnomaliImportTool.Infrastructure/FileProcessing
528K	developer-package/src/AnomaliImportTool.Infrastructure
4.0K	developer-package/src/AnomaliImportTool.Core/ApiClient
4.0K	developer-package/src/AnomaliImportTool.Core/Security
4.0K	developer-package/src/AnomaliImportTool.Core/DocumentProcessing
68K	developer-package/src/AnomaliImportTool.Core/Interfaces
84K	developer-package/src/AnomaliImportTool.Core/Services
148K	developer-package/src/AnomaliImportTool.Core/Models
320K	developer-package/src/AnomaliImportTool.Core
20K	developer-package/src/AnomaliImportTool.Uno/.vscode
12K	developer-package/src/AnomaliImportTool.Uno/.run
8.0K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/WebAssembly/WasmScripts
12K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/WebAssembly/wwwroot
8.0K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/WebAssembly/WasmCSS
44K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/WebAssembly
8.0K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/iOS/Media.xcassets/LaunchImages.launchimage
12K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/iOS/Media.xcassets
32K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/iOS
8.0K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/Desktop
8.0K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/Android/Assets
12K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/Android/Resources/values
20K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/Android/Resources
48K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms/Android
136K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Platforms
16K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Assets/Icons
12K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Assets/Splash
36K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Assets
28K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/ViewModels
16K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Properties/PublishProfiles
24K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Properties
4.0K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Views
12K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Strings/en
16K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Strings
8.0K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Services/Endpoints
12K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno/Services
312K	developer-package/src/AnomaliImportTool.Uno/AnomaliImportTool.Uno
392K	developer-package/src/AnomaliImportTool.Uno
8.0K	developer-package/src/AnomaliImportTool.UI/Commands
16K	developer-package/src/AnomaliImportTool.UI/DependencyInjection
8.0K	developer-package/src/AnomaliImportTool.UI/Extensions
24K	developer-package/src/AnomaliImportTool.UI/Assets/Png
8.0K	developer-package/src/AnomaliImportTool.UI/Assets/Ico
36K	developer-package/src/AnomaliImportTool.UI/Assets
200K	developer-package/src/AnomaliImportTool.UI/ViewModels
8.0K	developer-package/src/AnomaliImportTool.UI/Properties/PublishProfiles
32K	developer-package/src/AnomaliImportTool.UI/Properties
208K	developer-package/src/AnomaliImportTool.UI/Views
40K	developer-package/src/AnomaliImportTool.UI/Controls
52K	developer-package/src/AnomaliImportTool.UI/Themes
16K	developer-package/src/AnomaliImportTool.UI/Application
464K	developer-package/src/AnomaliImportTool.UI/Services
64K	developer-package/src/AnomaliImportTool.UI/ResourceDesigner
8.0K	developer-package/src/AnomaliImportTool.UI/Converters
1.2M	developer-package/src/AnomaliImportTool.UI
296K	developer-package/src/AnomaliImportTool.WinUI/Services
300K	developer-package/src/AnomaliImportTool.WinUI
2.7M	developer-package/src
260K	developer-package/binaries
4.0K	developer-package/scripts/build
60K	developer-package/scripts
3.1M	developer-package
440K	developer-package-v0.1.0-beta.tar.gz
16K	documentation/user-guides
20K	documentation/user-guide/support
120K	documentation/user-guide
40K	documentation/api
28K	documentation/examples
132K	documentation/architecture
20K	documentation/support
428K	documentation
100K	documentation-v0.1.0-beta.tar.gz


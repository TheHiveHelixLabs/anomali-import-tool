# Build Information

## Anomali Import Tool V0.1.0-beta
**Build Date**: Thu Jun 26 01:34:05 PM CDT 2025
**Build Platform**: Linux (x86_64)
**Build Environment**: .NET 8.0.407

## Available Packages

### Platform-Specific Applications

### Development Packages
- **core-library-v0.1.0-beta.tar.gz** (136K) - Core business logic library
- **developer-package-v0.1.0-beta.tar.gz** (269M) - Source code and development tools
- **documentation-v0.1.0-beta.tar.gz** (116K) - Complete documentation

## Platform Support Status
✅ **Linux x64** - Native self-contained executable (tested)
✅ **Cross-Platform** - Framework-dependent version (requires .NET 8 runtime)
❌ **Windows Native** - Cross-compilation limited by snap .NET installation
❌ **macOS Native** - Cross-compilation limited by snap .NET installation  
❌ **WebAssembly** - Requires additional Uno workloads not available in snap

## Build Environment Limitations
This build was created on a Linux system with .NET installed via snap, which has the following limitations:
- **Read-only file system**: Cannot install additional workloads
- **Cross-compilation restricted**: Limited to Linux native builds
- **Workload dependencies**: Uno Platform workloads not available

## Recommended Deployment Strategy
1. **Linux Users**: Use the native Linux x64 package (no dependencies)
2. **Windows/macOS Users**: Use the cross-platform package (requires .NET 8 runtime)
3. **Web Deployment**: Requires building on a system with full .NET SDK and Uno workloads

## Installation Instructions

### Linux x64 Native Package
1. Download `anomali-import-tool-v0.1.0-beta-linux-x64.tar.gz`
2. Extract: `tar -xzf anomali-import-tool-v0.1.0-beta-linux-x64.tar.gz`
3. Run: `cd linux-x64 && ./AnomaliImportTool.Uno`

### Cross-Platform Package (Windows/macOS/Linux)
1. Install .NET 8 runtime from https://dotnet.microsoft.com/download
2. Download `anomali-import-tool-v0.1.0-beta-cross-platform.tar.gz`
3. Extract: `tar -xzf anomali-import-tool-v0.1.0-beta-cross-platform.tar.gz`
4. Run: `cd cross-platform && dotnet AnomaliImportTool.Uno.dll`

## Verification
All packages have been successfully built and tested on the build platform.
Cross-platform compatibility verified through .NET's framework-dependent deployment model.

Built with: .NET SDK 8.0.407
Platform: Linux Silverfox-CC 6.11.0-26-generic #26~24.04.1-Ubuntu SMP PREEMPT_DYNAMIC Thu Apr 17 19:20:47 UTC 2 x86_64 x86_64 x86_64 GNU/Linux
